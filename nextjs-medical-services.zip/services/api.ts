
import { MedicalService } from '../types/MedicalService';

export const fetchMedicalServices = async (): Promise<MedicalService[]> => {
  const response = await fetch('/api/medicalServices');
  if (!response.ok) {
    throw new Error('Failed to fetch medical services');
  }
  return response.json();
};
