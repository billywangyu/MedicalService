
import { MedicalService } from '../types/MedicalService';

interface MedicalServicesListProps {
  services: MedicalService[];
}

export default function MedicalServicesList({ services }: MedicalServicesListProps) {
  return (
    <ul>
      {services.map((service) => (
        <li key={service.id}>
          <h2>{service.name}</h2>
          <p>{service.description}</p>
          <p>Emergency Service: {service.emergency_service ? 'Yes' : 'No'}</p>
        </li>
      ))}
    </ul>
  );
}
