
export interface MedicalService {
  id: number;
  city_town_id: number;
  name: string;
  type: string;
  contact_info: string | null;
  operating_hours: string | null;
  address: string | null;
  emergency_service: boolean;
  description: string | null;
}
