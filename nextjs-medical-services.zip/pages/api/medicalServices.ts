
import { neon } from '@neondatabase/serverless';
import { NextApiRequest, NextApiResponse } from 'next';
import { MedicalService } from '../../types/MedicalService';

const sql = neon(process.env.DATABASE_URL!);

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<MedicalService[] | { error: string }>
) {
  try {
    const query = 'SELECT * FROM medical_services';
    const result = await sql<MedicalService[]>`${query}`;
    res.status(200).json(result);
  } catch (error) {
    console.error('Error fetching medical services:', error);
    res.status(500).json({ error: 'Failed to fetch medical services' });
  }
}
