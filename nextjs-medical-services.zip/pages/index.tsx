
import { useState, useEffect } from 'react';
import { MedicalService } from '../types/MedicalService';
import { fetchMedicalServices } from '../services/api';

export default function Home() {
  const [services, setServices] = useState<MedicalService[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const data = await fetchMedicalServices();
        setServices(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h1>Medical Services</h1>
      <ul>
        {services.map((service) => (
          <li key={service.id}>
            <h2>{service.name}</h2>
            <p>{service.description}</p>
            <p>Emergency Service: {service.emergency_service ? 'Yes' : 'No'}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
